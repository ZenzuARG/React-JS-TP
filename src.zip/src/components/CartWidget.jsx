import React from 'react';

const CartWidget = () => {
  return (
    <div style={{ fontSize: "1.5rem", cursor: "pointer" }}>
      🛒 <span style={{ fontWeight: "bold" }}>3</span>
    </div>
  );
};


export default CartWidget;
